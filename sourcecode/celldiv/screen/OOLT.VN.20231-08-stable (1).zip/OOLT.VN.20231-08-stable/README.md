# OOLT.VN.20231-08

**OOLT 2023.1 Mini Project - Topic 06: Demonstration of types of cell division**

**Group Members:**

Nguyễn Hữu Đức - 20210192

Đàm Trần Ngọc Đức - 20210208

Hồ Văn Đức - 20215037

Bùi Mạnh Dũng - 20215010

**Demo Video: ...**
